const DatabaseAccess = require('./databaseAccess');
const db = new DatabaseAccess('./meuBanco.db');

async function testar() {
  await db.executarComando('CREATE TABLE IF NOT EXISTS pessoas (id INTEGER PRIMARY KEY, nome TEXT)');
  await db.executarComando('INSERT INTO pessoas (nome) VALUES (?)', ['Maria']);
  const resultado = await db.executarConsulta('SELECT * FROM pessoas');
  console.log(resultado);
}

testar();

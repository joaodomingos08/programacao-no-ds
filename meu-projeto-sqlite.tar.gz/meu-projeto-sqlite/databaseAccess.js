const sqlite3 = require('sqlite3').verbose();

class DatabaseAccess {
  constructor(dbPath) {
    this.db = new sqlite3.Database(dbPath);
  }
  executarComando(query, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(query, params, function(err) {
        if (err) reject(err);
        else resolve(this);
      });
    });
  }
  executarConsulta(query, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
}
module.exports = DatabaseAccess;
